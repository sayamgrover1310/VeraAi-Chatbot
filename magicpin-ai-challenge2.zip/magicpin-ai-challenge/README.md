# Vera merchant assistant — submission

**Approach.** `compose(category, merchant, trigger, customer)` in `bot.py` is a deterministic, dependency-free
composer. It dispatches on `trigger.kind` (19 merchant-facing + 7 customer-facing kinds, plus a generic fallback), picks
the single most relevant fact from the four contexts (digest item by id, peer-stat gap, live offer, review theme,
slot list, deadline), and writes one message: name → verifiable fact + source → why-now → one CTA in the last sentence.
Customer-facing messages are `merchant_on_behalf`, honour `language_pref`, consent and preferred slots.
`conversation_handlers.respond()` handles multi-turn: auto-reply ladder (prompt once → wait 24h → end), explicit
opt-out → end, frustration → apologise then exit, off-topic → decline and steer back, "not now" → wait, commitment
("let's do it", "join") → execute the next step immediately, never re-qualify. `server.py` exposes the 5 endpoints
(+ optional `/v1/teardown`) with idempotent versioned context storage, dedup by `suppression_key`, one send per
merchant per tick, a 3-unanswered cap, and consent-based restraint.

**Trade-offs.** No LLM at runtime: it is deterministic, sub-millisecond, cannot hallucinate and needs no API key or
`pip install`; the cost is less fluent prose on unusual triggers. Where a trigger payload is a placeholder or
contradicts the merchant's own numbers (e.g. `perf_dip` on a merchant whose views rose), the bot says what the data
actually shows instead of asserting the trigger. No URLs are emitted (`api-call-examples.md` treats them as a hard
fail). `expires_at` is ignored because the simulated clock is unknown; dedup is used instead.

**What would have helped most.** Real trigger payloads for the generated triggers (half are `placeholder: true`),
appointment times for `appointment_tomorrow`, per-merchant slot availability, an affected-customer count for recalls,
and a real "social proof" feed (what peers in the same locality did) — the brief's biggest untapped lever, which I did
not fake.

Run: `python server.py` (PORT env, default 8080) · self-test: `python test_bot.py` · regenerate: `python build_submission.py`
