# Process Log — magicpin "Vera" Merchant AI Challenge

Running log of everything done, in order, with the reasoning. Updated as work proceeds.

## 1. Understanding the task (read everything first)

Files read: `challenge-brief.md`, `challenge-testing-brief.md`, `engagement-design.md`, `engagement-research.md`,
`examples/case-studies.md`, `examples/api-call-examples.md`, `judge_simulator.py`, `dataset/*` (5 categories,
10 merchant seeds, 15 customer seeds, 25 trigger seeds, `generate_dataset.py`).

**What is being asked:** build "Vera", a WhatsApp merchant-assistant bot. Given 4 contexts
(category, merchant, trigger, optional customer) produce the next message. Deliverables:

| Deliverable | Purpose |
|---|---|
| `bot.py` with `compose(category, merchant, trigger, customer)` | Pure function, deterministic, <30s |
| `submission.jsonl` (30 lines) | One message per canonical test pair `T01..T30` |
| `README.md` (1 page) | Approach, trade-offs, what extra context would help |
| `conversation_handlers.py` with `respond(state, msg)` | Optional multi-turn (tie-breaker) |
| A live HTTP server: `/v1/healthz /v1/metadata /v1/context /v1/tick /v1/reply` (+ optional `/v1/teardown`) | The judge harness calls it at a public URL |

**Scoring:** 5 dimensions x 10 (specificity, category fit, merchant fit, trigger relevance, engagement compulsion),
then post-submission context injection (new digest items / perf snapshots / triggers / customers), then a multi-turn
replay for the top 10 (auto-reply hell, intent transition, hostile/off-topic). Operational penalties for timeouts,
malformed JSON, empty bodies, repeated bodies.

## 2. Key findings that shaped the design (the non-obvious bits)

1. **The dataset is only seeds.** Running `dataset/generate_dataset.py` expands to 50 merchants / 200 customers / 100
   triggers and writes `test_pairs.json` (the canonical 30 pairs). Output is in `expanded/`.
2. **Half of the 30 test pairs have `{"placeholder": true}` trigger payloads** and generated merchants have almost no
   data (no offers, no history, no signals, `customer_aggregate` = one number). The composer must produce something
   specific and honest from merchant + category facts only, never inventing.
3. **Triggers can contradict the merchant data**, e.g. `perf_dip` on a merchant whose numbers went *up* (T25),
   `perf_spike` on +2% (T27), `chronic_refill_due` on a dentist's customer (T08), `recall_due` on a yoga studio (T29),
   `appointment_tomorrow` with no appointment time (T03/T04). Rule: never assert what the data contradicts; reframe
   honestly (e.g. "traffic is fine, conversion is the gap").
4. **URLs:** the brief says allowed, but `api-call-examples.md` (F.4) says a URL in the body is a hard fail (-3).
   Decision: never emit URLs.
5. **Trigger `expires_at` is in Apr-Jun 2026** while the judge's simulated `now` is unknown (the local simulator sends
   real `utcnow()`). Filtering by expiry could silence the bot completely, so expiry is ignored; dedup by
   `suppression_key` is used instead.
6. **Case-study bodies must not be copied** (similarity check). Also some case-study "facts" (e.g. "22 of your customers
   were dispensed these batches", "Saturday IPL -12%" is real in digest, "₹1,420 total") are computed/fabricated, which
   the judge penalises as fabrication. Every number in my messages must trace to a context field.
7. **Local `judge_simulator.py` heuristics** (used as a floor): intent reply must contain one of
   `done/sending/draft/here/confirm/proceed/next` and none of `would you/do you/can you tell/what if/how about`;
   hostile must `end` (or apologise); 4 identical auto-replies should end.

## 3. Architecture decision

**Deterministic, rule + template composer with zero dependencies (Python stdlib only).**

Why not an LLM at runtime:
- No API key was available in this environment, so an LLM path could not be tested end-to-end. Untested code on the
  critical path is a bigger risk than slightly less fluent prose.
- Brief requires determinism and <30s; a template composer gives both trivially and can never hallucinate a fact.
- The graders reward specificity/fit/relevance, which come from *selecting the right facts per trigger kind*, i.e. logic.
- Stdlib `http.server` means no `pip install` on the deploy host, i.e. fewer ways to fail at the last minute.

Layout:
- `bot.py` — `compose()`; one composer per trigger kind + generic fallback; validation pass.
- `conversation_handlers.py` — `respond()`; auto-reply / opt-out / hostile / intent / off-topic / question / not-now.
- `server.py` — the 5 endpoints, in-memory context store, tick planner, conversation state.
- `build_submission.py` — regenerates `submission.jsonl` from `expanded/test_pairs.json`.
- `test_bot.py` — self-checks (schema, no URLs, no taboo words, no repeated bodies, endpoint flows).

(Sections below are appended as work progresses.)

## 4. What was built (in order)

1. **Expanded the dataset** with `generate_dataset.py` -> `expanded/` (50 merchants, 200 customers, 100 triggers,
   `test_pairs.json` = the canonical 30 pairs T01-T30).
2. **`bot.py` (composer).** First draft, then a critical read of all 30 outputs found real defects which were fixed:
   English body + Hinglish tail (jarring) -> Hinglish only for salons/restaurants/pharmacies, English for dentists/gyms;
   gendered Hindi verbs removed; broken sentences ("uska a Google post"); internal jargon ("competitor-radar") removed;
   duplicated facts (CTR twice); IPL message recommended a Tue-Thu BOGO on a weekend -> now says it doesn't run tonight
   and proposes a delivery-only combo, and flags the merchant's 4 late-delivery reviews; pharmacy customer was offered a
   "slot" -> now "send your list, we'll keep it ready"; a "+5% calls" was called "growth" -> now "steady week"; an ISO
   date leaked into T30 -> formatted; `perf_dip` on a merchant whose numbers rose -> honest reframe (traffic fine,
   conversion is the gap).
3. **`conversation_handlers.py`** (multi-turn) and **`server.py`** (5 endpoints + teardown).
4. **`build_submission.py`** -> `submission.jsonl` (30 rows, schema-validated).
5. **`test_bot.py`** end-to-end: pushes all 255 contexts, checks healthz counts, 409 on stale version, ticks all 100
   triggers, verifies every action has all fields, no URL, no empty/duplicate body, no category taboo word, dedup on
   re-tick, auto-reply ladder (send/wait/end), intent->action, hostile->end, abuse then off-topic, not-now->wait.
   Found and fixed a real bug (server double-counted its own reply as a repeat and swallowed every send).
6. **Ran the organisers' `judge_simulator.py`** scenarios (warmup, auto-reply, intent, hostile) against the server: all pass.

## 5. Results
- `python test_bot.py` -> ALL PASS (76 actions from 100 triggers; the rest deliberately suppressed: same merchant/customer
  in one tick, no customer consent, dedup).
- `submission.jsonl`: 30 valid rows, bodies 150-575 chars.

## 6. What the user still has to do (cannot be done from this machine)
1. Put the bot on a public URL (server must stay up for the whole test window): e.g. `ngrok http 8080` after
   `python server.py`, or deploy the folder to Render/Railway/Fly (`Procfile` included, no dependencies).
2. Set `TEAM_NAME`, `TEAM_MEMBERS`, `CONTACT_EMAIL` env vars (shown at `/v1/metadata`).
3. Submit on the portal: public URL + `bot.py`, `submission.jsonl`, `README.md` (+ `conversation_handlers.py`).
4. Optional: run `judge_simulator.py` with an LLM key for a mock score.

## 7. Known limits (honest)
- No LLM: prose is templated; unusual trigger kinds get the generic fallback.
- Scores against the real LLM judge are unknown; only structural/behavioural checks were run.

## 8. Spec-compliance audit (VERA_FINAL_MASTER_CHALLENGE_SPECIFICATION) and fixes
User supplied a master spec; audited the build against it. Gaps found and fixed:
1. **Equal context version** now returns 200 no-op (was 409); older version still 409; higher replaces.
2. **Trigger expiry vs simulated time**: `/v1/tick` now skips triggers whose `expires_at` < `now`. Safety valve: if `now` is
   later than *every* stored expiry (wall clock, not the dataset's epoch) expiry is ignored so the bot never goes silent.
3. **Empty != negative**: "no offer is live" -> "I don't see a live offer on file" everywhere.
4. **No invented scarcity**: removed "Limited seats / Limited slots" from drafted posts.
5. **Consent**: reminder opt-in is not promo consent. Offers are mentioned in customer messages only when `consent.scope`
   covers promotions/offers/winback (recall with real slots keeps the price of the service being booked).
6. Unknown-question fallback no longer claims capabilities ("I don't have that detail... I won't guess").
7. Softened "biggest visibility lever" to "a key visibility lever".
Tests updated (equal-version 200, older 409, expiry on simulated clock, wall-clock fallback); `python test_bot.py` ALL PASS;
`submission.jsonl` regenerated (30 rows).
Still open: public deployment, and the judgment call that dentists/gyms get English-only (spec encourages Hinglish when `hi`).
