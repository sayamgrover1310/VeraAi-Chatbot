"""Multi-turn handling: respond(state, merchant_message, ctx=None) -> reply action dict.

state: {"turns": [{"from","msg"}], "auto_count": int, "hostile_count": int, "ended": bool,
        "bot_bodies": [str], "kind": trigger kind, "merchant_id", "customer_id"}
ctx:   {"category","merchant","trigger","customer"} (any may be None)
Returns {"action": "send"|"wait"|"end", ...} exactly as the /v1/reply contract requires.
"""
from __future__ import annotations

import re

from bot import biz, cat_offer, active_offers, salute, digest_by_id, first_sentences, slug

AUTO = re.compile(
    r"(thank you for contacting|thanks for contacting|will (get back|respond|reply)|our team will|"
    r"auto[- ]?reply|automated (assistant|message|response|reply)|this is an automated|"
    r"currently (unavailable|away|closed)|out of office|business hours|"
    r"aapki jaankari ke liye|hamari team tak|team tak pahuncha|shukriya.*(sujhaav|team)|"
    r"main ek automated|thank you for (your )?message|we have received your message)", re.I)
OPTOUT = re.compile(
    r"(\bstop\b|unsubscribe|not interested|don'?t (message|text|contact|call|send)|do not (message|contact|send)|"
    r"remove (me|my number)|leave me alone|band kar|mat bhej|nahi chahiye|no more messages)", re.I)
ABUSE = re.compile(r"(useless|spam|bother|annoying|stupid|idiot|waste of|nonsense|shut up|rubbish|fed up|irritat|harass|pagal|bakwas)", re.I)
OFFTOPIC = re.compile(r"\b(gst|itr|income tax|tax filing|loan|insurance|salary|payroll|court|lawyer|legal notice|visa|passport|"
                      r"cricket score|weather|recipe|horoscope|crypto|stock|share market|aadhaar|pan card)\b", re.I)
NOTNOW = re.compile(r"(\bnot now\b|\blater\b|\bbusy\b|call me (back|later)|tomorrow|\bkal\b|baad mein|abhi nahi|next week|in a meeting|remind me)", re.I)
COMMIT = re.compile(
    r"(let'?s do it|lets do it|go ahead|do it|proceed|sounds good|sign me up|i want to join|want to join|join magicpin|"
    r"mujhe .*(judna|join)|magicpin judna|haan\b|\bhan\b|kar do|karo\b|chalega|theek hai|ok(ay)?\b.*(send|do|go|start|proceed)|"
    r"\byes\b|\byep\b|\bsure\b|please (send|do|draft|go)|send (it|me)|what'?s next|whats next|next step|confirm|\bgo\b|\bok\b|okay)", re.I)
QUESTION = re.compile(r"(\?|\bhow\b|\bwhat\b|\bwhy\b|\bwhen\b|\bkitna\b|\bkya\b|\bkaise\b|\bprice\b|\bcost\b|\bcharge)", re.I)
DEVANAGARI = re.compile(r"[ऀ-ॿ]")
HINDI_WORDS = re.compile(r"\b(hai|hain|kya|kar|karo|nahi|haan|aap|mujhe|hum|kal|abhi|bhej|dijiye|chahiye|theek|accha|achha)\b", re.I)


def _norm(s):
    return re.sub(r"[^a-z0-9]+", " ", (s or "").lower()).strip()


def is_hindi(msg):
    return bool(DEVANAGARI.search(msg) or len(HINDI_WORDS.findall(msg)) >= 2)


def _topic(kind):
    return {"research_digest": "the research summary", "regulation_change": "the compliance checklist", "cde_opportunity": "the webinar reminder",
            "perf_dip": "the recovery plan", "perf_spike": "the follow-up post", "recall_due": "the appointment", "festival_upcoming": "the festive campaign",
            "gbp_unverified": "the verification", "renewal_due": "the renewal", "supply_alert": "the recall list"}.get(kind, "this")


def _draft_post(ctx):
    m = (ctx or {}).get("merchant") or {}
    cat = (ctx or {}).get("category") or {}
    offer = (active_offers(m) or [cat_offer(cat) if cat else "a service+price offer"])[0]
    loc = (m.get("identity") or {}).get("locality", "")
    return "\"{} at {}{}. Message us to book.\"".format(offer, biz(m) if m else "our place", ", " + loc if loc else "")


def _action_body(state, ctx, hi):
    kind = state.get("kind") or ""
    m = (ctx or {}).get("merchant") or {}
    cat = (ctx or {}).get("category") or {}
    t = (ctx or {}).get("trigger") or {}
    sal = salute(m) if m else ""
    if kind == "research_digest" and cat:
        item = digest_by_id(cat, (t.get("payload") or {}).get("top_item_id")) or (cat.get("digest") or [{}])[0]
        pcl = (cat.get("patient_content_library") or [{}])[0]
        return ("Done — here's what I'm sending next. Summary: {} Draft note for your {}: \"{}\" Reply CONFIRM and I'll send it; next I'll line up the follow-up.").format(
            first_sentences(item.get("summary", ""), 200), "patients" if slug(m) == "dentists" else "customers",
            first_sentences(pcl.get("body", "Short, plain-language takeaway for your customers."), 200))
    if kind == "regulation_change" and cat:
        item = digest_by_id(cat, (t.get("payload") or {}).get("top_item_id")) or {}
        return ("Done — here's the draft checklist: (1) list every X-ray/IOPA setup in the clinic, (2) note film speed or sensor type for each, "
                "(3) record it in your SOP with the date. {} Reply CONFIRM and I'll format it as a 1-pager for your file.").format(
            (item.get("actionable") or "").rstrip(".") + "." if item.get("actionable") else "")
    if kind == "supply_alert":
        return "Sending the list now — first the atorvastatin customers, then a draft WhatsApp note for replacement pickup. Reply CONFIRM to send the note to them."
    if kind == "cde_opportunity":
        return "Done — slot saved and I'll remind you an hour before. Next: want the 2-line takeaway note after the session? Reply CONFIRM to keep it."
    return ("Done — starting now. Here's the draft post: {} Next step: reply CONFIRM and I'll publish it and send you the reply template for enquiries.").format(_draft_post(ctx))


def respond(state: dict, msg: str, ctx: dict | None = None, from_role: str = "merchant") -> dict:
    msg = (msg or "").strip()
    turns = state.setdefault("turns", [])
    prev_msgs = [_norm(x["msg"]) for x in turns if x.get("from") == from_role]
    turns.append({"from": from_role, "msg": msg})
    if state.get("ended"):
        return {"action": "end", "rationale": "Conversation already closed; not re-engaging."}
    hi = is_hindi(msg)

    if OPTOUT.search(msg) and not AUTO.search(msg):
        state["ended"] = True
        return {"action": "end", "rationale": "Explicit opt-out / not interested: closing and suppressing this conversation."}

    # auto-reply: canned phrasing OR the identical text seen before
    if AUTO.search(msg) or (_norm(msg) and _norm(msg) in prev_msgs):
        state["auto_count"] = state.get("auto_count", 0) + 1
        n = state["auto_count"]
        if n == 1:
            topic = _topic(state.get("kind"))
            body = ("Lagta hai yeh auto-reply hai 😊 Owner jab dekhein, bas YES likh dein — main {} turant bhej dungi.".format(topic)
                    if hi else "Looks like an auto-reply 😊 When the owner sees this, just reply YES and I'll send {} right away.".format(topic))
            return {"action": "send", "body": body, "cta": "binary_yes_no", "rationale": "Canned auto-reply detected; one explicit prompt aimed at the human owner, no extra qualifying questions."}
        if n == 2:
            return {"action": "wait", "wait_seconds": 86400, "rationale": "Same auto-reply again: owner isn't at the phone; back off 24h."}
        state["ended"] = True
        return {"action": "end", "rationale": "Auto-reply {}x with no human signal; closing instead of burning turns.".format(n)}
    state["auto_count"] = 0

    if from_role == "customer":
        return _customer_reply(state, msg, ctx, hi)

    if ABUSE.search(msg):
        state["hostile_count"] = state.get("hostile_count", 0) + 1
        if state["hostile_count"] >= 2:
            state["ended"] = True
            return {"action": "end", "rationale": "Repeated frustration; closing the conversation politely."}
        return {"action": "send", "body": "Sorry about that — I'll keep it short and only message when it's genuinely useful. If you'd rather pause, just say STOP.",
                "cta": "none", "rationale": "Frustration without an explicit opt-out: one-line apology + easy exit, no pitch."}

    if OFFTOPIC.search(msg):
        m = (ctx or {}).get("merchant") or {}
        back = _topic(state.get("kind"))
        return {"action": "send",
                "body": "That one's outside what I can help with — best left to your CA/advisor. Back to {} for {}: shall I go ahead? Reply YES.".format(back, biz(m) if m else "you"),
                "cta": "binary_yes_no", "rationale": "Off-topic ask politely declined; steers back to the original thread without losing it."}

    if NOTNOW.search(msg) and not COMMIT.search(msg.replace("tomorrow", "")):
        long_ = bool(re.search(r"tomorrow|\bkal\b|next week", msg, re.I))
        return {"action": "wait", "wait_seconds": 86400 if long_ else 3600, "rationale": "Merchant asked for time; backing off {}.".format("a day" if long_ else "an hour")}

    if COMMIT.search(msg) and not (QUESTION.search(msg) and not re.search(r"(yes|go ahead|let'?s|do it|next|join|kar do|haan)", msg, re.I)):
        body = _action_body(state, ctx, hi)
        if body in state.get("bot_bodies", []):
            return {"action": "wait", "wait_seconds": 1800, "rationale": "Would repeat the previous message verbatim; waiting for the merchant's confirmation instead."}
        state.setdefault("bot_bodies", []).append(body)
        return {"action": "send", "body": body, "cta": "binary_confirm_cancel", "rationale": "Merchant committed: switched from pitching to executing the concrete next step; no qualifying questions."}

    # a genuine question / free text: answer with what we know, keep one clear next step
    back = _topic(state.get("kind"))
    body = ("I don't have that detail in what I can see, so I won't guess. What I can do right now is {} — want me to go ahead? Reply YES.".format(back)
            if not hi else "Yeh detail mere paas nahi hai, isliye andaza nahi lagaungi. Abhi main {} par kaam kar sakti hoon — aage badhun? YES likh dijiye.".format(back))
    if body in state.get("bot_bodies", []):
        return {"action": "wait", "wait_seconds": 3600, "rationale": "Avoiding a verbatim repeat; waiting."}
    state.setdefault("bot_bodies", []).append(body)
    return {"action": "send", "body": body, "cta": "binary_yes_no", "rationale": "Answered from known context, single binary next step."}


def _customer_reply(state, msg, ctx, hi):
    t = (ctx or {}).get("trigger") or {}
    m = (ctx or {}).get("merchant") or {}
    slots = ((t.get("payload") or {}).get("available_slots") or (t.get("payload") or {}).get("next_session_options") or [])
    if OPTOUT.search(msg):
        state["ended"] = True
        return {"action": "end", "rationale": "Customer opted out; closing."}
    pick = re.match(r"^\s*([12])\b", msg)
    if pick and len(slots) >= int(pick.group(1)):
        lbl = slots[int(pick.group(1)) - 1].get("label", "your slot")
        return {"action": "send", "body": "Booked — {} at {}. See you then! Reply RESCHEDULE if anything changes.".format(lbl, biz(m) if m else "us"), "cta": "none",
                "rationale": "Customer picked a slot; confirmed it exactly as offered."}
    if COMMIT.search(msg):
        lbl = slots[0].get("label") if slots else None
        return {"action": "send", "body": ("Confirmed — {} is held for you. Reply RESCHEDULE if anything changes.".format(lbl) if lbl else "Confirmed — we've noted it and the team will message you the exact time shortly."),
                "cta": "none", "rationale": "Customer said yes; confirming without re-asking."}
    return {"action": "send", "body": "Thanks — tell us a day and time that suits you and we'll confirm it here.", "cta": "open_ended", "rationale": "Customer replied free-text; asking for a preferred time only."}
