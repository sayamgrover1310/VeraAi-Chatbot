"""Vera bot HTTP server (stdlib only). Run: python server.py  [PORT env, default 8080]

Endpoints: GET /v1/healthz, GET /v1/metadata, POST /v1/context, POST /v1/tick,
POST /v1/reply, POST /v1/teardown (optional wipe).
"""
from __future__ import annotations

import json
import os
import threading
import time
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from bot import compose, salute
from conversation_handlers import respond

START = time.time()
LOCK = threading.RLock()
SCOPES = ("category", "merchant", "customer", "trigger")
MAX_ACTIONS = 20
MAX_UNANSWERED = 3

CTX: dict = {}          # (scope, context_id) -> {"version": int, "payload": dict}
CONVS: dict = {}        # conversation_id -> state dict
SENT_KEYS: set = set()  # suppression keys already used
SENT_BODIES: dict = {}  # merchant_id -> set(body)
UNANSWERED: dict = {}   # merchant_id -> bot sends without a reply
BLOCKED: set = set()    # merchants who opted out
MERCH_AUTO: dict = {}   # merchant_id -> consecutive auto-replies


def now_iso():
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def get(scope, cid):
    e = CTX.get((scope, cid))
    return e["payload"] if e else None


def counts():
    c = {s: 0 for s in SCOPES}
    for (s, _) in CTX:
        c[s] += 1
    return c


# --------------------------------------------------------------------- handlers
def h_context(body):
    scope, cid, ver, payload = body.get("scope"), body.get("context_id"), body.get("version"), body.get("payload")
    if scope not in SCOPES:
        return 400, {"accepted": False, "reason": "invalid_scope", "details": "scope must be one of {}".format(list(SCOPES))}
    if not cid or not isinstance(ver, int) or not isinstance(payload, dict):
        return 400, {"accepted": False, "reason": "malformed", "details": "need context_id, integer version, object payload"}
    with LOCK:
        cur = CTX.get((scope, cid))
        if cur and cur["version"] == ver:  # idempotent re-post: successful no-op
            return 200, {"accepted": True, "ack_id": "ack_{}_v{}".format(cid, ver), "stored_at": now_iso()}
        if cur and cur["version"] > ver:
            return 409, {"accepted": False, "reason": "stale_version", "current_version": cur["version"]}
        CTX[(scope, cid)] = {"version": ver, "payload": payload}
    return 200, {"accepted": True, "ack_id": "ack_{}_v{}".format(cid, ver), "stored_at": now_iso()}


def _params(body, sal):
    sentences = [s.strip() for s in body.replace("\n", " ").split(". ") if s.strip()]
    return [sal, sentences[0][:200] if sentences else body[:200], sentences[-1][:200] if len(sentences) > 1 else ""]


def _ts(s):
    try:
        return datetime.fromisoformat(str(s).replace("Z", "+00:00")).astimezone(timezone.utc)
    except Exception:
        return None


def h_tick(body):
    ids = body.get("available_triggers") or []
    cands = []
    now = _ts(body.get("now"))
    with LOCK:
        exps = [_ts((e["payload"] or {}).get("expires_at")) for (sc, _), e in CTX.items() if sc == "trigger"]
        exps = [x for x in exps if x]
        # honour expiry against the simulated clock; if `now` is past EVERY stored expiry the clock
        # is not in the dataset's epoch (e.g. wall-clock), so expiry carries no signal and is ignored
        use_expiry = bool(now and exps and now <= max(exps))
        for tid in ids:
            t = get("trigger", tid)
            if not t:
                continue
            mid = t.get("merchant_id")
            m = get("merchant", mid)
            cat = get("category", (m or {}).get("category_slug"))
            if not (m and cat) or mid in BLOCKED:
                continue
            if UNANSWERED.get(mid, 0) >= MAX_UNANSWERED:
                continue
            if use_expiry:
                ex = _ts(t.get("expires_at"))
                if ex and ex < now:
                    continue
            key = t.get("suppression_key") or tid
            if key in SENT_KEYS:
                continue
            cust = None
            if t.get("scope") == "customer":
                cust = get("customer", t.get("customer_id"))
                if not cust:
                    continue
                if not (cust.get("consent") or {}).get("scope") or (cust.get("preferences") or {}).get("reminder_opt_in") is False:
                    continue  # no consent on file -> restraint
            cands.append((-(t.get("urgency") or 1), tid, t, m, cat, cust))
        cands.sort(key=lambda x: (x[0], x[1]))
        actions, seen = [], set()
        for _, tid, t, m, cat, cust in cands:
            mid = m["merchant_id"]
            grp = (mid, t.get("customer_id"))
            if grp in seen or len(actions) >= MAX_ACTIONS:
                continue
            if cust is None and (mid, None) in seen:
                continue
            r = compose(cat, m, t, cust)
            if not r["body"] or r["body"] in SENT_BODIES.get(mid, set()):
                continue
            seen.add(grp)
            conv = "conv_{}_{}".format(mid, tid)
            if conv in CONVS:
                continue
            CONVS[conv] = {"turns": [{"from": "bot", "msg": r["body"]}], "kind": t.get("kind"), "merchant_id": mid,
                           "customer_id": t.get("customer_id"), "trigger_id": tid, "bot_bodies": [r["body"]]}
            SENT_KEYS.add(t.get("suppression_key") or tid)
            SENT_BODIES.setdefault(mid, set()).add(r["body"])
            UNANSWERED[mid] = UNANSWERED.get(mid, 0) + 1
            actions.append({
                "conversation_id": conv, "merchant_id": mid, "customer_id": t.get("customer_id"),
                "send_as": r["send_as"], "trigger_id": tid,
                "template_name": "{}_{}_v1".format("merchant" if r["send_as"] == "merchant_on_behalf" else "vera", t.get("kind", "generic")),
                "template_params": _params(r["body"], salute(m)),
                "body": r["body"], "cta": r["cta"], "suppression_key": r["suppression_key"], "rationale": r["rationale"],
            })
    return 200, {"actions": actions}


def h_reply(body):
    cid = body.get("conversation_id")
    msg = body.get("message")
    if not cid or msg is None:
        return 400, {"action": "end", "rationale": "malformed reply request"}
    mid, cust_id, role = body.get("merchant_id"), body.get("customer_id"), body.get("from_role") or "merchant"
    with LOCK:
        st = CONVS.setdefault(cid, {"turns": [], "kind": None, "merchant_id": mid, "customer_id": cust_id, "bot_bodies": []})
        mid = mid or st.get("merchant_id")
        m = get("merchant", mid) if mid else None
        t = get("trigger", st.get("trigger_id")) if st.get("trigger_id") else None
        cat = get("category", (m or {}).get("category_slug")) if m else None
        cust = get("customer", cust_id or st.get("customer_id")) if (cust_id or st.get("customer_id")) else None
        ctx = {"category": cat, "merchant": m, "trigger": t, "customer": cust}
        if mid:
            st["auto_count"] = max(st.get("auto_count", 0), MERCH_AUTO.get(mid, 0))
        res = respond(st, str(msg), ctx, role)
        if mid:
            MERCH_AUTO[mid] = st.get("auto_count", 0)
            UNANSWERED[mid] = 0 if st.get("auto_count", 0) == 0 else UNANSWERED.get(mid, 0)
            if res.get("action") == "end" and ("opt-out" in res.get("rationale", "") or "frustration" in res.get("rationale", "").lower()):
                BLOCKED.add(mid)
        if res.get("action") == "send":
            b = res.get("body", "")
            if not b.strip():
                return 200, {"action": "wait", "wait_seconds": 3600, "rationale": "Avoiding an empty body."}
            if b not in st["bot_bodies"]:
                st["bot_bodies"].append(b)
            st["turns"].append({"from": "bot", "msg": b})
    return 200, res


def h_health():
    with LOCK:
        return 200, {"status": "ok", "uptime_seconds": int(time.time() - START), "contexts_loaded": counts()}


def h_meta():
    return 200, {"team_name": os.environ.get("TEAM_NAME", "Team Vera"), "team_members": os.environ.get("TEAM_MEMBERS", "Deepanshu Agarwal").split(","),
                 "model": "deterministic rule-based composer (no LLM at runtime)",
                 "approach": "dispatch by trigger.kind; every fact read from the 4 contexts; honest fallbacks for thin payloads; rule-based multi-turn handler",
                 "contact_email": os.environ.get("CONTACT_EMAIL", "deepanshuagarwal946@gmail.com"), "version": "1.0.0",
                 "submitted_at": now_iso()}


def h_teardown():
    with LOCK:
        for d in (CTX, CONVS, SENT_BODIES, UNANSWERED, MERCH_AUTO):
            d.clear()
        SENT_KEYS.clear()
        BLOCKED.clear()
    return 200, {"status": "wiped"}


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def _send(self, code, obj):
        data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        p = self.path.split("?")[0]
        if p == "/v1/healthz":
            return self._send(*h_health())
        if p == "/v1/metadata":
            return self._send(*h_meta())
        self._send(404, {"error": "not_found"})

    def do_POST(self):
        p = self.path.split("?")[0]
        try:
            n = int(self.headers.get("Content-Length") or 0)
            raw = self.rfile.read(n) if n else b"{}"
            body = json.loads(raw.decode("utf-8") or "{}")
            if not isinstance(body, dict):
                raise ValueError("body must be an object")
        except Exception as e:
            return self._send(400, {"accepted": False, "reason": "malformed_json", "details": str(e)})
        try:
            if p == "/v1/context":
                return self._send(*h_context(body))
            if p == "/v1/tick":
                return self._send(*h_tick(body))
            if p == "/v1/reply":
                return self._send(*h_reply(body))
            if p == "/v1/teardown":
                return self._send(*h_teardown())
        except Exception as e:  # never crash the judge's run; degrade safely
            if p == "/v1/tick":
                return self._send(200, {"actions": []})
            if p == "/v1/reply":
                return self._send(200, {"action": "wait", "wait_seconds": 1800, "rationale": "internal error: {}".format(type(e).__name__)})
            return self._send(500, {"error": type(e).__name__})
        self._send(404, {"error": "not_found"})

    def log_message(self, *a):
        pass


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "8080"))
    print("Vera bot listening on :{}".format(port), flush=True)
    ThreadingHTTPServer(("0.0.0.0", port), Handler).serve_forever()
