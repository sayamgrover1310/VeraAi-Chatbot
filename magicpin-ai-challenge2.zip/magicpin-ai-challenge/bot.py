"""Vera composer: compose(category, merchant, trigger, customer) -> message dict.

Deterministic, stdlib-only. Every number/name in a message is read from the four
contexts. When a trigger payload is thin (placeholder) we fall back to merchant +
category facts, and we never assert something the data contradicts.
"""
from __future__ import annotations

import re
from datetime import datetime

MONTHS = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"]
AUDIENCE = {"dentists": "patients", "salons": "clients", "restaurants": "guests",
            "gyms": "members", "pharmacies": "customers"}
# categories whose voice profile is natural Hinglish; dentists/gyms stay English-primary
HINGLISH_CATS = {"salons", "restaurants", "pharmacies"}


# ----------------------------------------------------------------- small helpers
def _g(d, *path, default=None):
    for p in path:
        if not isinstance(d, dict) or p not in d:
            return default
        d = d[p]
    return d if d is not None else default


def money(n):
    return "₹{:,}".format(int(round(n)))


def pct(x):
    return "{:.0f}%".format(abs(x) * 100)


def ctr_s(x):
    return "{:.1f}%".format(x * 100)


def signed(x):
    return "{}{}".format("+" if x >= 0 else "-", pct(x))


def dmy(iso):
    """'2026-11-05T18:00:00+05:30' -> '5 Nov'"""
    try:
        d = datetime.strptime(str(iso)[:10], "%Y-%m-%d")
        return "{} {}".format(d.day, d.strftime("%b"))
    except Exception:
        return str(iso or "")


def first_sentences(text, max_chars=230):
    text = (text or "").strip()
    if len(text) <= max_chars:
        return text
    out = ""
    for s in re.split(r"(?<=[.!?])\s+", text):
        if out and len(out) + len(s) + 1 > max_chars:
            break
        out = (out + " " + s).strip()
    return out or text[:max_chars].rstrip()


def humanize(s):
    return str(s or "").replace("_", " ").strip()


def slug(m):
    return m.get("category_slug", "")


def hinglish(m):
    return slug(m) in HINGLISH_CATS and "hi" in (_g(m, "identity", "languages", default=[]) or [])


def hin(m, en, hi_):
    return hi_ if hinglish(m) else en


def salute(m):
    o = (_g(m, "identity", "owner_first_name", default="") or "").strip()
    name = _g(m, "identity", "name", default="there")
    if slug(m) == "dentists" and o:
        return o if o.lower().startswith("dr") else "Dr. " + o
    return o or name


def biz(m):
    return _g(m, "identity", "name", default="your business")


def sender(m):
    """How the merchant introduces themselves to their own customer."""
    o = (_g(m, "identity", "owner_first_name", default="") or "").strip()
    if o and not o.lower().startswith("dr") and slug(m) != "dentists":
        return "{} from {}".format(o, biz(m))
    return biz(m)


def active_offers(m):
    return [o["title"] for o in (m.get("offers") or []) if o.get("status") == "active"]


def soft_offer(m):
    """Merchant's own active offer, preferring a 'free' one for re-engagement."""
    offs = active_offers(m)
    for o in offs:
        if "free" in o.lower():
            return o
    return offs[0] if offs else None


def cat_offer(cat):
    """Category-catalogue service+price offer; only ever used as a *suggestion*."""
    cat_ = cat.get("offer_catalog") or []
    cands = [o for o in cat_ if o.get("type") == "service_at_price"] or cat_
    return cands[0]["title"] if cands else "a service+price offer"


def digest_by_id(cat, did):
    for d in cat.get("digest", []):
        if d.get("id") == did:
            return d
    return None


def digest_pick(cat, kinds, ids=()):
    for did in ids:
        if did:
            d = digest_by_id(cat, did)
            if d:
                return d
    for k in kinds:  # priority order; newest (last) item of that kind
        items = [d for d in cat.get("digest", []) if d.get("kind") == k]
        if items:
            return items[-1]
    return None


def peer(cat, key):
    return _g(cat, "peer_stats", key)


def perf_facts(cat, m):
    """(strong_positive, biggest_gap) phrases from merchant vs peer stats; either may be None."""
    p, f = m.get("performance", {}), cat.get("peer_stats", {})
    rows = []  # (ratio, label, mine, theirs)
    if p.get("ctr") and f.get("avg_ctr"):
        rows.append((p["ctr"] / f["avg_ctr"], "CTR", ctr_s(p["ctr"]), ctr_s(f["avg_ctr"])))
    if p.get("calls") is not None and f.get("avg_calls_30d"):
        rows.append((p["calls"] / f["avg_calls_30d"], "calls", "{}".format(p["calls"]), "{}".format(f["avg_calls_30d"])))
    if p.get("views") and f.get("avg_views_30d"):
        rows.append((p["views"] / f["avg_views_30d"], "views", "{:,}".format(p["views"]), "{:,}".format(f["avg_views_30d"])))
    if not rows:
        return None, None
    hi_, lo_ = max(rows), min(rows)
    fmt = lambda r: "{} {} vs peer avg {}".format(r[1] if r[1] == "CTR" else "30-day " + r[1], r[2], r[3])
    return (fmt(hi_) if hi_[0] >= 1.15 else None), (fmt(lo_) if lo_[0] <= 0.85 else None)


def insight(cat, m):
    pos, gap = perf_facts(cat, m)
    return gap or pos


def profile_gaps(m):
    """Merchant-state reasons a listing under-performs, from real fields only."""
    out = []
    sub = m.get("subscription", {})
    if sub.get("status") == "expired":
        out.append("your plan expired {} days ago, so profile upkeep is paused".format(sub.get("days_since_expiry", "a few")))
    if not _g(m, "identity", "verified", default=True):
        out.append("the Google profile is still unverified")
    if not active_offers(m):
        out.append("I don't see a live offer on file")
    if "delivery_not_set_up" in (m.get("signals") or []):
        out.append("home delivery isn't set up")
    return out


def beat_for(cat, needle=None, month=None):
    for b in cat.get("seasonal_beats", []):
        note = b.get("note") or ""
        if needle and needle.lower() in note.lower():
            return b
        if month is not None and _month_in(b.get("month_range", ""), month):
            return b
    return None


def _month_in(rng, month):
    ms = [MONTHS.index(t[:3].lower()) + 1 for t in re.findall(r"[A-Za-z]{3,}", rng) if t[:3].lower() in MONTHS]
    if not ms:
        return False
    if len(ms) == 1:
        return month == ms[0]
    a, b = ms[0], ms[1]
    return (a <= month <= b) if a <= b else (month >= a or month <= b)


# ------------------------------------------------------------ customer language
def promo_ok(c):
    """Reminder opt-in is not promotional consent: offers only if consent.scope covers promotions."""
    sc = " ".join(_g(c, "consent", "scope", default=[]) or []).lower()
    return any(k in sc for k in ("promo", "offer", "winback"))


def cust_lang(c):
    lp = (_g(c, "identity", "language_pref", default="english") or "english").lower()
    if lp == "hi":
        return "hi"
    for k in ("hi", "ta", "te", "kn"):
        if lp.startswith(k):
            return "hinglish" if k == "hi" else k
    return "en"


def cust_greet(c):
    """(greeting, dependent_name_or_None). Handles '(parent: X)' and 'Mr. X' names."""
    raw = _g(c, "identity", "name", default="there")
    lang = cust_lang(c)
    mt = re.match(r"^(.*?)\s*\(parent:\s*(.*?)\)\s*$", raw)
    who, dep = (mt.group(2), mt.group(1)) if mt else (raw, None)
    if re.match(r"^(Mr|Mrs|Ms)\.", who):
        return "Namaste {} ji".format(who.split(".", 1)[1].strip()), dep
    hello = {"hi": "Namaste", "ta": "Vanakkam", "te": "Namaskaram", "kn": "Namaskara"}.get(lang, "Hi")
    return "{} {}".format(hello, who), dep


def ch(c, en, hinglish_, hi_=None):
    lang = cust_lang(c)
    if lang == "hi":
        return hi_ or hinglish_
    if lang == "hinglish":
        return hinglish_
    return en


# ============================================================= MERCHANT-FACING
def _deliverable(s):
    return {"salons": "a Google post + a 4-line WhatsApp reply for price queries",
            "restaurants": "a Google post + a 3-line reply for 'menu/price' DMs",
            "gyms": "a class-promo post + a short reply for trial enquiries",
            "dentists": "a patient-ed post + a short reply for enquiry DMs",
            "pharmacies": "a shelf note + a WhatsApp broadcast for repeat customers"}.get(s, "a Google post + a short reply template")


def _trend_s(x):
    """'ORS_demand_+40' -> 'ORS +40%'"""
    mt = re.match(r"^(.*?)_demand_([+-])(\d+)$", str(x))
    if mt:
        return "{} {}{}%".format(humanize(mt.group(1)).replace("cold cough", "cold/cough"), mt.group(2), mt.group(3))
    return humanize(x)


def _time_s(iso):
    try:
        d = datetime.strptime(iso[:16], "%Y-%m-%dT%H:%M")
        h = d.hour % 12 or 12
        return "{}{}{}".format(h, ":{:02d}".format(d.minute) if d.minute else "", "pm" if d.hour >= 12 else "am")
    except Exception:
        return ""


def m_research(cat, m, t, c):
    p = t.get("payload", {}) or {}
    item = digest_pick(cat, ["research", "trend", "tech", "seasonal"], (p.get("top_item_id"),))
    if not item:
        return m_generic(cat, m, t, c)
    sal, aud = salute(m), AUDIENCE.get(slug(m), "customers")
    src, title, kind = item.get("source", ""), item.get("title", "").rstrip("."), item.get("kind")
    head = "{}, {}: {}.".format(sal, src, title) if src else "{}, {}.".format(sal, title)
    if item.get("trial_n") and slug(m) == "dentists":
        head = head[:-1] + " ({:,}-patient study).".format(item["trial_n"])
    summ = first_sentences(item.get("summary", ""), 250)
    hr = _g(m, "customer_aggregate", "high_risk_adult_count")
    act = (item.get("actionable") or "").rstrip(".")
    if slug(m) == "dentists" and "high_risk" in item.get("patient_segment", "") and hr:
        rel = "You have {} high-risk adults on your roster — their recall interval is the thing to revisit.".format(hr)
    elif act:
        rel = "Takeaway: {}.".format(act)
    else:
        rel = ""
    one = aud[:-1] if aud.endswith("s") else aud
    cta = {"research": hin(m, "Want the 2-minute summary plus a short {} note you can forward?".format(one),
                           "2-minute summary + {} ko forward karne layak chhota note bhej doon?".format(one)),
           "trend": hin(m, "Want me to turn this into a Google post + offer angle for {}?".format(biz(m)),
                        "Isse {} ke liye Google post + offer angle bana doon?".format(biz(m))),
           "tech": hin(m, "Want a quick cost-vs-benefit check for your setup?", "Aapke setup ke liye quick cost-vs-benefit check kar doon?"),
           }.get(kind, hin(m, "Want me to draft the next step for {}?".format(biz(m)), "Iska next step draft kar doon?"))
    return " ".join(x for x in (head, summ, rel, cta) if x), "open_ended", \
        "Category digest ({}) cited with source; merchant-specific hook where data allows; one curiosity/reciprocity ask.".format(kind)


def m_regulation(cat, m, t, c):
    p = t.get("payload", {}) or {}
    item = digest_pick(cat, ["compliance"], (p.get("top_item_id"),))
    if not item:
        return m_generic(cat, m, t, c)
    sal = salute(m)
    dl = p.get("deadline_iso")
    title = re.sub(r"\s*effective\s+\d{4}-\d{2}-\d{2}", "", item.get("title", "")).rstrip(".")
    s = "{}, {} — {}".format(sal, item.get("source", "regulator circular"), title)
    s += ", effective {}.".format(dmy(dl)) if dl else "."
    s += " " + first_sentences(item.get("summary", ""), 260)
    act = (item.get("actionable") or "").rstrip(".")
    if act:
        s += " Action: {}.".format(act[0].lower() + act[1:])
    cta = hin(m, "Want me to draft a 1-page audit checklist you can drop into your SOP?", "Ek 1-page audit checklist bana doon jo SOP mein laga sako?")
    return s + " " + cta, "binary_yes_no", \
        "Compliance item with a hard date and source: loss aversion + specificity; offers a ready checklist (effort externalisation)."


def m_cde(cat, m, t, c):
    p = t.get("payload", {}) or {}
    item = digest_pick(cat, ["cde"], (p.get("digest_item_id"), p.get("top_item_id")))
    if not item:
        return m_generic(cat, m, t, c)
    sal = salute(m)
    when = ""
    if item.get("date"):
        when = "{}, {}".format(dmy(item["date"]), _time_s(item["date"]))
    title = re.sub(r"^[A-Za-z ]+:\s*", "", item.get("title", "")).rstrip(".")
    cr = p.get("credits") or item.get("credits")
    s = "{}, {} — '{}'{}.".format(sal, item.get("source", "CDE event").replace(" chapter calendar", ""), title, ", {}".format(when) if when else "")
    s += " " + first_sentences(item.get("summary", ""), 200)
    s += " {}{}".format("{} CDE credits. ".format(cr) if cr else "", ((item.get("actionable") or "").rstrip(".") + ".") if item.get("actionable") else "")
    cta = hin(m, "Want me to save the slot and remind you an hour before?", "Slot save karke ek ghante pehle yaad dila doon?")
    return s.strip() + " " + cta, "binary_yes_no", \
        "CDE event with date, credits and fee lifted from the digest; single low-friction reminder ask."


def m_seasonal(cat, m, t, c):
    p = t.get("payload", {}) or {}
    item = digest_pick(cat, ["seasonal"], (p.get("top_item_id"),))
    sal, aud = salute(m), AUDIENCE.get(slug(m), "customers")
    trends = [_trend_s(x) for x in (p.get("trends") or [])]
    src = (item or {}).get("source") if item and "summer" in (item.get("id", "") + item.get("title", "")).lower() else ""
    if trends:
        s = "{}, summer demand shift{}: {}.".format(sal, " ({})".format(src) if src else "", ", ".join(trends))
        s += " Restock the risers and bring them to the front shelf; the cold/cough stock can move back." if slug(m) == "pharmacies" else ""
        offs = active_offers(m)
        if offs and slug(m) == "pharmacies":
            s += " Your live '{}' pairs well with ORS/sunscreen bundles.".format(offs[0])
    elif item:
        s = "{}, {} ({}). {}".format(sal, item["title"].rstrip("."), item.get("source", ""), first_sentences(item.get("summary", ""), 220))
    else:
        return m_generic(cat, m, t, c)
    cta = hin(m, "Want a shelf-rearrange checklist + a WhatsApp broadcast to your repeat {}?".format(aud),
              "Shelf-rearrange checklist + repeat {} ke liye WhatsApp broadcast bana doon?".format(aud))
    return s + " " + cta, "binary_yes_no", \
        "Seasonal shift using the payload's own percentages and source; concrete deliverables tied to repeat customers."


def m_supply(cat, m, t, c):
    p = t.get("payload", {}) or {}
    item = digest_pick(cat, ["alert", "supply"], (p.get("alert_id"), p.get("top_item_id")))
    sal = salute(m)
    bat = p.get("affected_batches") or []
    mol = p.get("molecule") or "the flagged molecule"
    src = (item or {}).get("source", "CDSCO alert")
    s = "{}, urgent: {} flags a voluntary recall on {} batches{} (mfr {}). Sub-potency, no safety risk; replacement runs through the distributor return chain.".format(
        sal, src, mol, " " + " & ".join(bat) if bat else "", p.get("manufacturer") or "in the alert")
    n = _g(m, "customer_aggregate", "chronic_rx_count")
    asked = any(h.get("from") == "merchant" and ("list" in h.get("body", "").lower()) for h in (m.get("conversation_history") or []))
    s += " First step: pull those batches off the shelf."
    s += " As you asked, I'm filtering your {} chronic-Rx customers for {}.".format(n, mol) if (asked and n) else \
        (" I can filter your {} chronic-Rx customers for {}.".format(n, mol) if n else "")
    cta = hin(m, "Reply YES and I'll send the list plus a ready WhatsApp note for replacement pickup.",
              "YES bol dijiye — list + replacement pickup ka WhatsApp note bhej deta hoon.")
    return s + " " + cta, "binary_yes_no", \
        "Urgency-5 recall with batch numbers and source; ties to the merchant's earlier request for the list; no invented affected-customer count."


def m_competitor(cat, m, t, c):
    p = t.get("payload", {}) or {}
    sal = salute(m)
    name, dist, offer, od = p.get("competitor_name"), p.get("distance_km"), p.get("their_offer"), p.get("opened_date")
    pos = sorted([x for x in (m.get("review_themes") or []) if x.get("sentiment") == "pos"], key=lambda x: -x.get("occurrences_30d", 0))
    mine = soft_offer(m)
    if name:
        s = "{}, {} opened{}{}{}".format(sal, name, " {} km away".format(dist) if dist else " nearby", " on {}".format(dmy(od)) if od else "",
                                         ", listing '{}'.".format(offer) if offer else ".")
        if offer:
            s += " Yours is '{}' — I wouldn't chase their price.".format(mine) if mine else " I wouldn't chase their price."
        if pos:
            q = pos[0].get("common_quote")
            s += " Your edge is already in the reviews: {} mentions in 30 days{}.".format(
                pos[0]["occurrences_30d"], " (\"{}\")".format(q) if q else " for {}".format(humanize(pos[0]["theme"])))
        cta = hin(m, "Want me to draft a Google post that leads with that instead of price?", "Price ke bajay isi strength par ek Google post draft kar doon?")
        return s + " " + cta, "binary_yes_no", \
            "Competitor event with name/distance/offer from the payload; avoids a price war by using the merchant's own review strength."
    pos_f, _ = perf_facts(cat, m)
    strengths = []
    if _g(m, "customer_aggregate", "repeat_customer_pct"):
        strengths.append("{} repeat customers".format(pct(m["customer_aggregate"]["repeat_customer_pct"])))
    if pos_f:
        strengths.append(pos_f)
    s = "{}, a new competitor has just opened near {}. I don't have their menu or pricing yet, so I won't guess.".format(sal, _g(m, "identity", "locality", default="you"))
    if strengths:
        s += " Your side of the ledger: {}.".format(" and ".join(strengths))
    if mine:
        s += " '{}' is the offer to protect.".format(mine)
    cta = hin(m, "Want me to send a side-by-side of your listing vs theirs as soon as it goes live?", "Unki listing live hote hi side-by-side compare bhej doon?")
    return s + " " + cta, "binary_yes_no", \
        "Competitor trigger with an empty payload: says what is unknown instead of inventing a rival; anchors on the merchant's own strengths."


def m_curious(cat, m, t, c):
    sal, s = salute(m), slug(m)
    themes = sorted([x for x in (m.get("review_themes") or []) if x.get("sentiment") == "pos"], key=lambda x: -x.get("occurrences_30d", 0))
    offs = active_offers(m)
    q = {"salons": "which service are clients asking for most this week?",
         "restaurants": "what's moving most at {} this week — dine-in, delivery or one particular dish?".format(biz(m)),
         "gyms": "what are members asking for most right now — new batches, PT or something else?",
         "dentists": "which treatment enquiry is most common this week?",
         "pharmacies": "which category is moving fastest at your counter this week?"}.get(s, "what are customers asking for most this week?")
    hook = ""
    if themes:
        th = themes[0]
        hook = " {} reviews in the last 30 days praise {}{}.".format(th["occurrences_30d"], humanize(th["theme"]),
                                                                      " (\"{}\")".format(th["common_quote"]) if th.get("common_quote") else "")
    elif offs:
        hook = " Is '{}' still the lead?".format(offs[0])
    s1 = hin(m, "{}, quick pulse check: {}{}".format(sal, q, hook), "{}, ek quick pulse check: {}{}".format(sal, q, hook))
    cta = hin(m, "Reply with one line and I'll turn it into {} — 5 minutes on my side.".format(_deliverable(s)),
              "Bas ek line bhej dijiye, uske hisaab se main {} bana deta hoon — 5 minute ka kaam.".format(_deliverable(s)[2:]))
    return s1 + " " + cta, "open_ended", \
        "Weekly curious-ask: asking-the-merchant lever grounded in a real review/offer hook; reciprocity (deliverable) promised up-front."


def m_dormant(cat, m, t, c):
    p = t.get("payload", {}) or {}
    sal = salute(m)
    days, topic = p.get("days_since_last_merchant_message"), humanize(p.get("last_topic"))
    s = "{}, it's been {} since we last spoke{}.".format(sal, "{} days".format(days) if days else "a while", " ({} was the last topic)".format(topic) if topic else "")
    facts = []
    ins = insight(cat, m)
    if ins:
        facts.append(ins)
    d7 = _g(m, "performance", "delta_7d", default={}) or {}
    if d7.get("calls_pct") is not None and abs(d7["calls_pct"]) >= 0.05:
        facts.append("calls are {} {} this week".format("up" if d7["calls_pct"] > 0 else "down", pct(d7["calls_pct"])))
    if facts:
        s += " I checked your profile: {}.".format("; ".join(facts))
    if _g(m, "subscription", "status") == "expired":
        s += " Your plan expired {} days ago, so upkeep is paused.".format(_g(m, "subscription", "days_since_expiry", default="a few"))
    cta = hin(m, "Want a 3-line summary of what changed on your profile since then? Reply YES.",
              "Tab se profile par kya badla, 3 line mein bhej doon? YES likh dijiye.")
    return s + " " + cta, "binary_yes_no", \
        "Dormancy nudge kept low-pressure: reciprocity ('I checked') with real numbers, one binary ask, no renewal push."


def m_festival(cat, m, t, c):
    p = t.get("payload", {}) or {}
    sal = salute(m)
    fest, date, days = p.get("festival"), p.get("date"), p.get("days_until")
    beat = None
    if date:
        try:
            beat = beat_for(cat, month=int(str(date)[5:7]))
        except ValueError:
            beat = None
    beat = beat or beat_for(cat, needle="festival") or beat_for(cat, needle="diwali")
    offs = active_offers(m)
    if fest and date:
        s = "{}, {} is on {}{}.".format(sal, fest, dmy(date), " — {} days out, so there's time to build a pre-booking list".format(days) if days and days > 45 else
                                        (" — {} days out".format(days) if days else ""))
    else:
        s = "{}, the festive window is the next demand peak for {}.".format(sal, (cat.get("display_name") or "your category").lower())
    if beat:
        s += " Category pattern ({}): {}.".format(beat.get("month_range"), beat.get("note"))
    pos, _ = perf_facts(cat, m)
    if pos and not offs:
        s += " Your listing is already strong ({}).".format(pos)
    if len(offs) >= 2:
        s += " Your live '{}' and '{}' are the natural entry points.".format(offs[0], offs[1])
    elif offs:
        s += " Your live '{}' is the natural entry point.".format(offs[0])
    else:
        ex = [o["title"] for o in cat.get("offer_catalog", []) if any(k in o["title"].lower() for k in ("refer", "combo", "membership", "brunch", "bridal"))]
        s += " I don't see a live offer on file; a catalogue fit is '{}'.".format(ex[0] if ex else cat_offer(cat))
    n = _g(m, "customer_aggregate", "total_unique_ytd")
    if n:
        s += " {:,} customers came through this year — the easiest audience to re-activate.".format(n)
    cta = hin(m, "Want me to draft the festive post + a pre-booking message you can schedule?", "Festive post + pre-booking message draft kar doon jo aap schedule kar sako?")
    return s + " " + cta, "binary_yes_no", \
        "Festival trigger tied to the category's own seasonal beat, the merchant's offers and customer base; no festival invented when the payload lacks one."


def m_gbp(cat, m, t, c):
    p = t.get("payload", {}) or {}
    sal = salute(m)
    up = p.get("estimated_uplift_pct")
    path = humanize(p.get("verification_path") or "postcard or phone call")
    s = "{}, {} isn't Google-verified yet — a key visibility lever on your profile.".format(sal, biz(m))
    if up:
        s += " Verified listings get roughly {} more discovery (our estimate).".format(pct(up))
    s += " Google verifies by {}; I can walk you through it step by step.".format(path)
    ins = perf_facts(cat, m)[1]
    if ins:
        s += " Right now: {}.".format(ins)
    gaps = [g for g in profile_gaps(m) if "unverified" not in g]
    if gaps:
        s += " Also on the list: {}.".format(gaps[0])
    cta = hin(m, "Reply YES and I'll start verification now — about 5 minutes of your time.", "YES bol dijiye, main abhi verification start kar deta hoon — bas 5 minute ka kaam.")
    return s + " " + cta, "binary_yes_no", \
        "Unverified GBP with payload path + uplift estimate; loss aversion and a single binary commitment."


def m_ipl(cat, m, t, c):
    p = t.get("payload", {}) or {}
    sal = salute(m)
    match, venue, wk = p.get("match"), p.get("venue"), p.get("is_weeknight")
    tm = _time_s(p.get("match_time_iso", ""))
    offs = active_offers(m)
    late = [x for x in (m.get("review_themes") or []) if "deliver" in x.get("theme", "") and x.get("sentiment") == "neg"]
    s = "{}, {}{} tonight{}.".format(sal, match or "an IPL match", " at {}".format(venue) if venue else "", ", {}".format(tm) if tm else "")
    if wk is False:
        s += " magicpin order data (Apr 2026): Saturday IPL matches cut restaurant covers 12% as people watch at home, while weeknight matches lift covers 18%. Tonight isn't a weeknight, so I'd skip the dine-in push and sell for home-viewing."
        if offs and not any("tue" in o.lower() for o in offs):
            s += " Lead with your live '{}'.".format(offs[0])
        elif offs:
            s += " Your '{}' doesn't run tonight, so use a delivery-only match combo instead (catalogue fit: 'Match-night Combo @ ₹399').".format(offs[0])
        if late:
            s += " Keep ETAs honest — you have {} late-delivery reviews in the last 30 days.".format(late[0].get("occurrences_30d"))
        cta = hin(m, "Want me to draft a delivery-only banner + an Insta story for tonight?", "Aaj raat ke liye delivery-only banner + Insta story draft kar doon?")
    else:
        s += " Weeknight matches lift restaurant covers ~18% (magicpin order data, Apr 2026) — worth a dine-in push."
        combo = [o["title"] for o in cat.get("offer_catalog", []) if "match" in o["title"].lower()]
        s += " Catalogue fit: '{}'.".format(combo[0]) if combo else ""
        cta = hin(m, "Want me to draft the match-night post + a table-hold message?", "Match-night post + table-hold message draft kar doon?")
    return s + " " + cta, "binary_yes_no", \
        "IPL event read via the weeknight flag using the digest's own 12%/18% numbers; contrarian, honest advice that respects offer validity and a live delivery complaint theme."


def m_milestone(cat, m, t, c):
    p = t.get("payload", {}) or {}
    sal = salute(m)
    metric, now_v, goal = p.get("metric"), p.get("value_now"), p.get("milestone_value")
    themes = sorted([x for x in (m.get("review_themes") or []) if x.get("sentiment") == "pos"], key=lambda x: -x.get("occurrences_30d", 0))
    if metric and now_v and goal:
        s = "{}, small win: {} is at {} — just {} away from {}.".format(sal, "your " + humanize(metric), now_v, goal - now_v, goal)
        if themes:
            s += " '{}' is your strongest theme ({} mentions in 30 days), so happy customers are already there.".format(humanize(themes[0]["theme"]), themes[0]["occurrences_30d"])
        cta = hin(m, "Want me to draft a 2-line WhatsApp ask for recent happy customers, plus a 'thank you for {}' post?".format(goal),
                  "Recent happy customers ke liye 2-line WhatsApp ask + '{} ka thank-you' post bana doon?".format(goal))
        return s + " " + cta, "binary_yes_no", \
            "Imminent milestone from the payload; effort externalisation (ready review-ask) with social-proof framing."
    pf = m.get("performance", {})
    pos, gap = perf_facts(cat, m)
    s = "{}, quick read on {}'s last 30 days: {:,} views, {} calls.".format(sal, biz(m), pf.get("views", 0), pf.get("calls", 0))
    if pos and gap:
        s += " The good news: {}. The gap: {}.".format(pos, gap)
        cta = hin(m, "Want me to draft two Google posts to lift the weaker number while the strong one holds?", "Kamzor number ko upar laane ke liye 2 Google posts draft kar doon?")
    else:
        s += " {}.".format((pos or gap or "steady against peers").capitalize())
        cta = hin(m, "Want me to draft a Google post to build on this?", "Isse aage badhane ke liye ek Google post draft kar doon?")
    return s + " " + cta, "binary_yes_no", \
        "Milestone trigger with no payload metric: reports only verifiable 30-day numbers vs peers rather than naming a milestone that isn't in the data."


def _worst(m, sign=-1):
    d = _g(m, "performance", "delta_7d", default={}) or {}
    c_ = [(v * sign, k[:-4]) for k, v in d.items() if k in ("views_pct", "calls_pct") and v is not None]
    if not c_:
        return None, None
    v, k = min(c_)
    return v * sign, k


def m_perf_dip(cat, m, t, c):
    p = t.get("payload", {}) or {}
    sal = salute(m)
    metric, dp, win, base = p.get("metric"), p.get("delta_pct"), p.get("window", "7d"), p.get("vs_baseline")
    if dp is None:
        dp, metric = _worst(m)
    gaps = profile_gaps(m)
    pf, d7 = m.get("performance", {}), _g(m, "performance", "delta_7d", default={}) or {}
    if dp is not None and dp <= -0.03:
        s = "{}, {} fell {} over the last {}{}.".format(sal, metric, pct(dp), win.replace("d", " days") if win.endswith("d") else win, " (baseline ~{})".format(base) if base else "")
        other = "views" if metric == "calls" else "calls"
        if d7.get(other + "_pct") is not None and d7[other + "_pct"] <= -0.03:
            s += " {} are down {} too.".format(other.capitalize(), pct(d7[other + "_pct"]))
        if gaps:
            s += " Fixable on your side: {}.".format("; ".join(gaps[:3]))
        offer = cat_offer(cat)
        cta = hin(m, "Want me to draft a service+price offer (e.g. '{}') and a Google post so it's live today?".format(offer),
                  "Ek service+price offer (jaise '{}') aur Google post draft kar doon taaki aaj hi live ho jaye?".format(offer))
        return s + " " + cta, "binary_yes_no", \
            "Dip confirmed by payload/merchant data; causes come only from merchant fields; concrete recovery deliverable."
    # trigger claims a dip but the merchant's own numbers do not show one
    pos, gap = perf_facts(cat, m)
    s = "{}, I checked before pinging you: views {} and calls {} this week, {:,} views and {} calls over 30 days.".format(
        sal, signed(d7.get("views_pct", 0)), signed(d7.get("calls_pct", 0)), pf.get("views", 0), pf.get("calls", 0))
    if pos and gap:
        s += " Strength: {}. Gap: {} — people see you and click, the drop-off is before the call.".format(pos.replace("30-day ", ""), gap.replace("30-day ", ""))
    elif gap:
        s += " Gap: {}.".format(gap)
    if gaps:
        s += " Likely drag: {}.".format("; ".join(gaps[:2]))
    cta = hin(m, "Want me to draft a call-focused Google post (service+price) to lift calls?", "Calls badhane ke liye service+price wala Google post draft kar doon?")
    return s + " " + cta, "binary_yes_no", \
        "perf_dip trigger contradicted by the merchant's own numbers: reports the real picture and targets the conversion gap instead of asserting a dip."


def m_perf_spike(cat, m, t, c):
    p = t.get("payload", {}) or {}
    sal = salute(m)
    metric, dp, base, drv = p.get("metric"), p.get("delta_pct"), p.get("vs_baseline"), p.get("likely_driver")
    if dp is None:
        dp, metric = _worst(m, sign=1)
    d7 = _g(m, "performance", "delta_7d", default={}) or {}
    if dp is not None and dp >= 0.10:
        s = "{}, {} are up {} over the last {}{}.".format(sal, metric, pct(dp), (p.get("window") or "7d").replace("d", " days"), " (baseline ~{})".format(base) if base else "")
        if drv:
            s += " Most likely driver: your {}.".format(humanize(drv))
        offer = soft_offer(m)
        if offer:
            s += " Convert the extra interest with your live '{}'.".format(offer)
        cta = hin(m, "Want me to draft a follow-up post in the same style to ride the momentum?", "Isi momentum par usi style ka ek aur post draft kar doon?")
        return s + " " + cta, "binary_yes_no", "Real spike from the payload with its likely driver credited; asks to repeat what worked."
    gaps = profile_gaps(m)
    s = "{}, steady week rather than a spike: views {} and calls {} vs last week.".format(sal, signed(d7.get("views_pct", 0)), signed(d7.get("calls_pct", 0)))
    ins = insight(cat, m)
    if ins:
        s += " For context, {}.".format(ins)
    if gaps:
        s += " The bigger lever is the profile itself: {}.".format("; ".join(gaps[:3]))
    cta = hin(m, "Want me to draft one post to convert the traffic you already have?", "Jo traffic aa raha hai use convert karne ke liye ek post draft kar doon?")
    return s + " " + cta, "binary_yes_no", \
        "perf_spike trigger with a small (<10%) real change: honest 'steady' framing, then the profile gaps that cap growth."


def m_seasonal_dip(cat, m, t, c):
    p = t.get("payload", {}) or {}
    sal = salute(m)
    d7 = _g(m, "performance", "delta_7d", default={}) or {}
    dv = p.get("delta_pct", d7.get("views_pct", 0))
    s = "{}, {} are down {} this week".format(sal, p.get("metric", "views"), pct(dv))
    if d7.get("calls_pct") is not None and d7["calls_pct"] < 0:
        s += " and calls {}".format(pct(d7["calls_pct"]))
    item = digest_pick(cat, ["seasonal"], ("d_2026W17_resolution_window",))
    if p.get("is_expected_seasonal") and item:
        s += " — that's the expected lull, not a problem: {} ({}). So don't chase it with ad spend.".format(item["title"].rstrip("."), item.get("source", ""))
    else:
        s += "."
    act, chn, pc = _g(m, "customer_aggregate", "total_active_members"), _g(m, "customer_aggregate", "monthly_churn_pct"), peer(cat, "monthly_churn_pct")
    if act and chn:
        s += " Where the effort pays: monthly churn is {} (about {} of your {} members){}.".format(pct(chn), int(act * chn + 0.5), act, " vs peer avg {}".format(pct(pc)) if pc else "")
    sched = digest_by_id(cat, "d_2026W17_class_schedule_optimization")
    if sched:
        s += " Also: 6-8am weekday slots run ~60% full across partner gyms vs 90%+ in the evening ({}).".format(sched.get("source", ""))
    cta = hin(m, "Want me to draft a 4-week member attendance challenge to hold onto them through the dip?", "Dip ke dauran members ko rokne ke liye 4-week attendance challenge draft kar doon?")
    return s + " " + cta, "binary_yes_no", \
        "Reframes an expected seasonal dip (anxiety pre-emption) with digest evidence, then redirects to retention using the merchant's own churn vs peer."


def m_review(cat, m, t, c):
    p = t.get("payload", {}) or {}
    sal = salute(m)
    th, occ, quote = p.get("theme"), p.get("occurrences_30d"), p.get("common_quote")
    rising = p.get("trend") == "rising"
    if not th:
        neg = sorted([x for x in (m.get("review_themes") or []) if x.get("sentiment") == "neg"], key=lambda x: -x.get("occurrences_30d", 0))
        if not neg:
            s = "{}, a recurring theme was flagged in {}'s recent reviews, but the detail isn't in my data yet, so I won't guess what it is.".format(sal, biz(m))
            cta = hin(m, "Want me to pull the last 30 days of reviews, group the top 3 themes and draft replies?", "Pichhle 30 din ke reviews nikaal kar top 3 themes aur replies draft kar doon?")
            return s + " " + cta, "binary_yes_no", "Review-theme trigger with no theme in payload or merchant data: says so rather than inventing one, offers to analyse."
        th, occ, quote = neg[0]["theme"], neg[0].get("occurrences_30d"), neg[0].get("common_quote")
    s = "{}, a pattern in your reviews: '{}' came up {} times in the last 30 days{}.".format(sal, humanize(th), occ, " and is rising" if rising else "")
    if quote:
        s += " Typical line: \"{}\".".format(quote)
    s += " Left unanswered, that's what the next customer reads first."
    cta = hin(m, "Want me to draft a polite public reply plus a short fix-note for your team? 5 minutes.", "Ek polite public reply + team ke liye chhota fix-note draft kar doon? 5 minute ka kaam.")
    return s + " " + cta, "binary_yes_no", \
        "Review theme from the payload (count, trend, quote): loss aversion plus a drafted reply and fix note."


def m_renewal(cat, m, t, c):
    p = t.get("payload", {}) or {}
    sal = salute(m)
    days, plan, amt = p.get("days_remaining", _g(m, "subscription", "days_remaining")), p.get("plan", _g(m, "subscription", "plan", default="plan")), p.get("renewal_amount")
    pf = m.get("performance", {})
    s = "{}, your {} plan has {} days left{}.".format(sal, plan, days, " (renewal {})".format(money(amt)) if amt else "")
    s += " Last 30 days: {:,} views, {} calls, {} direction requests — that's what upkeep protects.".format(pf.get("views", 0), pf.get("calls", 0), pf.get("directions", 0))
    cta = hin(m, "Reply YES and I'll send the renewal details here — nothing changes on your profile.", "YES bol dijiye, renewal details yahin bhej deta hoon — profile mein kuch nahi badlega.")
    return s + " " + cta, "binary_yes_no", "Renewal with real days/amount from the payload; loss aversion tied to the merchant's own 30-day numbers; single YES."


def m_winback(cat, m, t, c):
    p = t.get("payload", {}) or {}
    sal = salute(m)
    d, dip, lap = p.get("days_since_expiry", _g(m, "subscription", "days_since_expiry")), p.get("perf_dip_pct"), p.get("lapsed_customers_added_since_expiry")
    s = "{}, it's been {} days since {}'s plan expired{}.".format(sal, d, biz(m), " and views have slipped {}".format(pct(dip)) if dip else "")
    if lap:
        s += " {} more customers have drifted into 'lapsed' in that time.".format(lap)
    s += " Profile upkeep and offers have been paused meanwhile."
    cta = hin(m, "Reply YES and I'll reactivate and queue a win-back post + message to your lapsed customers today.", "YES bol dijiye, main reactivate karke aaj hi win-back post + lapsed customers ko message queue kar deta hoon.")
    return s + " " + cta, "binary_yes_no", "Win-back with expiry days, dip and lapsed count from the payload; loss aversion + one YES that triggers a full package."


def m_planning(cat, m, t, c):
    p = t.get("payload", {}) or {}
    sal = salute(m)
    topic = p.get("intent_topic", "")
    if "corporate" in topic or "bulk" in topic:
        base = None
        for o in active_offers(m):
            mt = re.search(r"₹\s*([\d,]+)", o)
            if mt and "thali" in o.lower():
                base = int(mt.group(1).replace(",", ""))
                break
        if base:
            tiers = [(n, int(round(base * f / 5.0) * 5)) for n, f in ((10, .91), (25, .87), (50, .81))]
            body = ("{}, here's a starter version of the corporate thali — edit freely:\n"
                    "• {}+ thalis @ {} each (vs {} retail) + free delivery\n"
                    "• {}+ thalis @ {} each + 2 free filter coffees\n"
                    "• {}+ thalis @ {} each + 1 free dosa platter\n"
                    "• Order by 5pm the day before; delivery in the 12:30–1pm window.\n"
                    "Tier prices are my proposal off your live '{}'; I haven't assumed any office list. "
                    "Reply GO and I'll publish it as a Google post and draft a 3-line WhatsApp for nearby offices.").format(
                sal, tiers[0][0], money(tiers[0][1]), money(base), tiers[1][0], money(tiers[1][1]), tiers[2][0], money(tiers[2][1]), soft_offer(m))
            return body, "binary_yes_no", "Merchant said yes to the corporate-thali idea: action mode, a full drafted artifact with tiers derived from his live thali price, no fabricated offices, one GO."
    if "kids" in topic and "yoga" in topic:
        prior = " ".join(h.get("body", "") for h in (m.get("conversation_history") or []) if h.get("from") == "vera")
        mt = re.search(r"₹\s*[\d,]+", prior)
        price = mt.group(0) if mt else None
        small = any("small" in x.get("theme", "") for x in (m.get("review_themes") or []))
        body = ("{}, here's the kids-yoga draft to review:\n"
                "• 4-week summer program, 3 classes/week, ages 7–12{}\n"
                "{}"
                "• Google post: \"Kids Yoga Summer Camp at {} — 4 weeks, ages 7–12. Message us to book.\"\n"
                "Send me your batch timings and I'll add the schedule line. Reply GO and I'll publish the post next.").format(
            sal, ", {} for the 4 weeks".format(price) if price else "", "• Small batches (your reviews already praise the small classes)\n" if small else "", biz(m))
        return body, "binary_yes_no", "Merchant asked what the kids-yoga program should look like: delivers the draft using the price Vera already proposed and her own 'small classes' review theme."
    offer = cat_offer(cat)
    s = "{}, here's a first draft for {} — edit freely:\n• Offer angle: a service+price hook (catalogue fit: '{}')\n• A 3-line Google post naming the offer and how to book\n• A 2-line WhatsApp for your existing {}\nReply GO and I'll publish the post and send you the WhatsApp text.".format(
        sal, humanize(topic) or "your idea", offer, AUDIENCE.get(slug(m), "customers"))
    return s, "binary_yes_no", "Planning-intent trigger: continues the merchant's own request with a drafted starter and a single GO."


def m_generic(cat, m, t, c=None):
    """Fallback for unknown kinds: uses whatever scalar payload facts exist + a peer comparison."""
    p = t.get("payload", {}) or {}
    facts = ["{}: {}".format(humanize(k), v) for k, v in p.items()
             if k not in ("placeholder", "metric_or_topic") and not isinstance(v, (dict, list)) and v not in (None, "")]
    ins = insight(cat, m)
    s = "{}, {} update for {}".format(salute(m), humanize(t.get("kind", "profile")), biz(m))
    s += " — {}".format("; ".join(facts[:3])) if facts else ""
    s += "."
    s += " For context, {}.".format(ins) if ins else ""
    offer = soft_offer(m) or cat_offer(cat)
    cta = hin(m, "Want me to draft the next step (e.g. a post around '{}')?".format(offer), "Iska next step (jaise '{}' par ek post) draft kar doon?".format(offer))
    return s + " " + cta, "open_ended", "Unknown trigger kind: anchors on whatever payload scalars exist plus a peer comparison; one next-step offer."


# ============================================================ CUSTOMER-FACING
def _slot_word(m):
    return {"restaurants": ("table", "order"), "pharmacies": ("refill", "medicine list")}.get(slug(m), ("slot", "slot"))


def cu_recall(cat, m, t, c):
    p = t.get("payload", {}) or {}
    greet, _ = cust_greet(c)
    slots = p.get("available_slots") or []
    svc = re.sub(r"^(\d+) month", r"\1-month", humanize(p.get("service_due")))
    last, due = _g(c, "relationship", "last_visit"), p.get("due_date")
    visits, offer = _g(c, "relationship", "visits_total"), soft_offer(m)
    icon = " 🦷" if slug(m) == "dentists" else ""
    who = sender(m)
    if not slots and not promo_ok(c):
        offer = None
    if slots and len(slots) >= 1:
        sl = [x["label"] for x in slots[:2]]
        opts = (sl[0] + (" ya " if cust_lang(c) in ("hinglish", "hi") else " or ") + sl[1]) if len(sl) > 1 else sl[0]
        if svc and due:
            head = ch(c, "{}, {} here{}. Your {} recall is due on {} (last visit {}).".format(greet, who, icon, svc, dmy(due), dmy(last)),
                      "{}, {} yahan{}. Aapki {} recall {} ko due hai (last visit {}).".format(greet, who, icon, svc, dmy(due), dmy(last)))
        else:
            head = ch(c, "{}, {} here{}. It's time for your next check-up.".format(greet, who, icon), "{}, {} yahan{}. Aapke next check-up ka time ho gaya hai.".format(greet, who, icon))
        mid = ch(c, " Two slots are held for you: {}.".format(opts) if len(sl) > 1 else " A slot is held for you: {}.".format(opts),
                 " Aapke liye {} hold hain: {}.".format("2 slots" if len(sl) > 1 else "1 slot", opts))
        if offer:
            mid += ch(c, " {} is live.".format(offer), " {} live hai.".format(offer))
        cta = ch(c, " Reply 1 for the first, 2 for the second, or tell us a time that suits you.", " 1 ya 2 reply kijiye, ya apna suitable time bata dijiye.")
        return head + mid + cta, "multi_choice_slot", \
            "Customer recall via the merchant's number: real slots/price from context, language pref honoured, booking-flow choice with an escape hatch."
    a, b = _slot_word(m)
    s = ch(c, "{}, {} here{}. It's been a while since your last visit on {}{}.".format(greet, who, icon, dmy(last), " — {} visits with us so far".format(visits) if visits else ""),
           "{}, {} yahan{}. Aapki last visit {} ko thi{} — kaafi din ho gaye.".format(greet, who, icon, dmy(last), ", ab tak {} visits".format(visits) if visits else ""))
    if offer and "free" in offer.lower():
        s += ch(c, " {} is on us when you're back.".format(offer), " Wapas aane par {} hamari taraf se.".format(offer))
    elif offer:
        s += ch(c, " {} is live right now.".format(offer), " {} abhi live hai.".format(offer))
    s += ch(c, " Reply YES and we'll hold a {} for you this week — no commitment.".format(a), " YES reply kijiye, hum is hafte ek {} hold kar dete hain — koi commitment nahi.".format(a))
    return s, "binary_yes_no", \
        "Recall trigger with no due-date/slots in the payload: uses only the customer's real last visit/visit count and the merchant's real offer; no invented slots."


def cu_lapsed(cat, m, t, c):
    p = t.get("payload", {}) or {}
    greet, _ = cust_greet(c)
    last, visits = _g(c, "relationship", "last_visit"), _g(c, "relationship", "visits_total")
    days = p.get("days_since_last_visit")
    focus = humanize(p.get("previous_focus")) or humanize(_g(c, "preferences", "training_focus"))
    months, offer = p.get("previous_membership_months"), (soft_offer(m) if promo_ok(c) else None)
    time_h = {"weekday_evening": "a weekday-evening", "weekday_7am": "a weekday-morning"}.get(_g(c, "preferences", "preferred_slots", default=""), "")
    icon = " 🦷" if slug(m) == "dentists" else ""
    a, b = _slot_word(m)
    s = ch(c, "{}, {} here{}.".format(greet, sender(m), icon), "{}, {} yahan{}.".format(greet, sender(m), icon))
    if days:
        wk = int(round(days / 7.0))
        s += ch(c, " It's been about {} weeks since your last visit — happens to most people, no judgment.".format(wk),
                " Aapki last visit ko lagbhag {} hafte ho gaye — sabke saath hota hai, koi baat nahi.".format(wk))
    else:
        s += ch(c, " It's been a little while since your last visit on {}{}.".format(dmy(last), " (visit #{} with us)".format(visits) if False else ""),
                " Aapki last visit {} ko thi, kaafi din ho gaye.".format(dmy(last)))
    if months and focus:
        s += " You worked on {} with us for {} months — that progress is worth keeping.".format(focus, months)
    elif visits and slug(m) != "pharmacies":
        s += ch(c, " You've been in {} times, so we know what works for you.".format(visits), " Aap {} baar aa chuke hain, aapki pasand hum jaante hain.".format(visits))
    if offer:
        s += (ch(c, " '{}' is live, so coming back costs nothing to try.".format(offer), " '{}' live hai — wapas aake try karna free hai.".format(offer)) if "free" in offer.lower()
              else ch(c, " '{}' is live for you.".format(offer), " '{}' abhi live hai.".format(offer)))
    if slug(m) == "pharmacies":
        s += ch(c, " If you need a refill or anything else, send the list here and we'll keep it ready (home delivery on request).",
                " Refill ya koi bhi dawai chahiye ho to list yahin bhej dijiye, hum ready rakhenge.")
        return s, "open_ended", "Lapsed pharmacy customer: no slot-booking framing (not applicable); offers to keep a list ready using only real visit data."
    s += ch(c, " Reply YES and we'll book {} {} for you — no commitment.".format(time_h or "a", a).replace("  ", " "),
            " YES reply kijiye, hum {} {} book kar dete hain — koi commitment nahi.".format(time_h or "ek", a).replace("  ", " "))
    return s, "binary_yes_no", "Lapsed-customer win-back: no-shame framing, honours previous goal and preferred slot, real live offer, single YES with no commitment."


def cu_appointment(cat, m, t, c):
    p = t.get("payload", {}) or {}
    greet, _ = cust_greet(c)
    when = p.get("slot_label") or p.get("time_label") or p.get("appointment_time")
    svc = humanize(p.get("service"))
    s = ch(c, "{}, a reminder from {}: you have an appointment tomorrow{}{}.".format(greet, biz(m), " at " + str(when) if when else "", " for " + svc if svc else ""),
           "{}, {} ki taraf se reminder: kal aapki appointment hai{}{}.".format(greet, biz(m), " (" + str(when) + ")" if when else "", " for " + svc if svc else ""))
    s += ch(c, " Reply YES to confirm, or send a time that works better and we'll move it.", " Confirm ke liye YES reply kijiye, ya koi aur time bata dijiye, hum shift kar denge.")
    return s, "binary_yes_no", "Appointment reminder; the payload has no slot time so none is invented; single confirm ask with a reschedule escape."


def cu_refill(cat, m, t, c):
    p = t.get("payload", {}) or {}
    mols = p.get("molecule_list") or []
    if slug(m) != "pharmacies" or not mols:
        body, _, _ = cu_recall(cat, m, {"payload": {}}, c)
        return body, "binary_yes_no", "chronic_refill_due received for a non-pharmacy business / no molecules on file: a refill claim would be fabricated, so this is a plain check-in built from real visit data."
    greet, _ = cust_greet(c)
    end = p.get("stock_runs_out_iso")
    offs = active_offers(m)
    senior = [o for o in offs if "senior" in o.lower()]
    deliv = [o for o in offs if "delivery" in o.lower()]
    loc = _g(m, "identity", "locality")
    nm = _g(c, "identity", "name", default="")
    who = "{} ji".format(nm.split(".", 1)[1].strip()) if re.match(r"^(Mr|Mrs|Ms)\.", nm) else "Aapki"
    s = "Namaste — {}{} yahan. ".format(biz(m), " ({})".format(loc) if loc else "")
    s += "{} ki {} monthly dawaiyaan ({}) {} ko khatam hongi. Same dose, same brand ka pack ready hai.".format(who, len(mols), ", ".join(mols), dmy(end) if end else "jald")
    if senior:
        s += " {} apply hoga.".format(senior[0])
    if deliv and p.get("delivery_address_saved"):
        mt = re.search(r"₹\s*[\d,]+", deliv[0])
        s += " Saved address par free home delivery bhi{}.".format(" ({} se upar ke order par)".format(mt.group(0)) if mt else "")
    s += " CONFIRM reply kijiye, hum dispatch kar dete hain. Dose mein koi badlav ho to bata dijiye."
    return s, "binary_confirm_cancel", "Chronic refill for a senior via family WhatsApp: exact molecules and run-out date from the payload, real offers (senior discount + free delivery); no invented price total."


def cu_trial(cat, m, t, c):
    p = t.get("payload", {}) or {}
    greet, dep = cust_greet(c)
    opts, trial = p.get("next_session_options") or [], p.get("trial_date")
    who = dep or "Your child"
    s = ch(c, "{}, {} here. {} attended the kids-yoga trial class{} — hope it was a good start!".format(greet, sender(m), who, " on " + dmy(trial) if trial else " recently"),
           "{}, {} yahan. {} ne{} kids-yoga trial kiya tha — umeed hai achha laga!".format(greet, sender(m), who, " " + dmy(trial) + " ko" if trial else " haal hi mein"))
    if opts:
        s += ch(c, " The next session is {}. Reply YES and I'll reserve a spot for {}.".format(opts[0]["label"], who),
                " Agla session {} ko hai. YES reply kijiye, {} ke liye spot reserve kar deta hoon.".format(opts[0]["label"], who))
    else:
        s += ch(c, " Reply YES and I'll share the next session slots.", " YES reply kijiye, agle session ke slots bhej deta hoon.")
    return s, "binary_yes_no", "Trial follow-up addressed to the parent (dependent named), real next-session slot from the payload, single YES to reserve."


def cu_bridal(cat, m, t, c):
    p = t.get("payload", {}) or {}
    greet, _ = cust_greet(c)
    wd, days, tr = p.get("wedding_date"), p.get("days_to_wedding"), p.get("trial_completed")
    win = humanize(p.get("next_step_window_open")) or "skin-prep"
    pref = _g(c, "preferences", "preferred_slots", default="")
    s = "{} 💍 {} here. ".format(greet, sender(m))
    s += "{} to your wedding on {} — the {} window is open now{}.".format("{} days".format(days) if days else "Time", dmy(wd) if wd else "the big day", win,
                                                                       ", following your bridal trial on {}".format(dmy(tr)) if tr else "")
    s += " Starting early gives your skin time to settle before the big day."
    s += " Reply YES and I'll hold a {} slot for the first session and share what's included.".format("Saturday" if "saturday" in pref else "preferred")
    return s, "binary_yes_no", "Bridal follow-up: exact days-to-wedding and program window from the payload, honours her Saturday preference; program price deliberately not invented."


def cu_generic(cat, m, t, c):
    greet, _ = cust_greet(c)
    last, offer = _g(c, "relationship", "last_visit"), (soft_offer(m) if promo_ok(c) else None)
    s = ch(c, "{}, {} here. It's been a while since your last visit on {}.".format(greet, sender(m), dmy(last)), "{}, {} yahan. Aapki last visit {} ko thi, kaafi din ho gaye.".format(greet, sender(m), dmy(last)))
    if offer:
        s += ch(c, " '{}' is live at the moment.".format(offer), " '{}' abhi live hai.".format(offer))
    s += ch(c, " Reply YES if you'd like us to hold a spot for you.", " Spot hold karwana ho to YES reply kijiye.")
    return s, "binary_yes_no", "Customer-scope trigger of an unknown kind: relationship-based check-in using only real visit/offer facts."


MERCHANT_KINDS = {
    "research_digest": m_research, "regulation_change": m_regulation, "cde_opportunity": m_cde,
    "category_seasonal": m_seasonal, "supply_alert": m_supply, "competitor_opened": m_competitor,
    "curious_ask_due": m_curious, "dormant_with_vera": m_dormant, "festival_upcoming": m_festival,
    "gbp_unverified": m_gbp, "ipl_match_today": m_ipl, "milestone_reached": m_milestone,
    "perf_dip": m_perf_dip, "perf_spike": m_perf_spike, "seasonal_perf_dip": m_seasonal_dip,
    "review_theme_emerged": m_review, "renewal_due": m_renewal, "winback_eligible": m_winback,
    "active_planning_intent": m_planning,
}
CUSTOMER_KINDS = {
    "recall_due": cu_recall, "customer_lapsed_soft": cu_lapsed, "customer_lapsed_hard": cu_lapsed,
    "appointment_tomorrow": cu_appointment, "chronic_refill_due": cu_refill,
    "trial_followup": cu_trial, "wedding_package_followup": cu_bridal,
}


# ==================================================================== entrypoint
_URL = re.compile(r"(https?://|www\.)\S+", re.I)


def _clean(body):
    body = _URL.sub("", body)
    body = re.sub(r"[ \t]{2,}", " ", body)
    body = re.sub(r" ([.,!?])", r"\1", body)
    return body.strip()


def compose(category: dict, merchant: dict, trigger: dict, customer: dict | None = None) -> dict:
    kind = trigger.get("kind", "")
    cust_facing = trigger.get("scope") == "customer" and customer is not None
    try:
        if cust_facing:
            body, cta, why = CUSTOMER_KINDS.get(kind, cu_generic)(category, merchant, trigger, customer)
            send_as = "merchant_on_behalf"
        else:
            body, cta, why = MERCHANT_KINDS.get(kind, m_generic)(category, merchant, trigger, customer)
            send_as = "vera"
        body = _clean(body)
        if not body:
            raise ValueError("empty body")
    except Exception as e:  # one odd payload must never break a whole tick
        body = "{}, quick update on {} — want me to share what I'm seeing on your profile? Reply YES.".format(salute(merchant), biz(merchant))
        cta, send_as, why = "binary_yes_no", "vera", "Fallback after composer error ({}).".format(type(e).__name__)
    supp = trigger.get("suppression_key") or "{}:{}".format(kind, merchant.get("merchant_id", ""))
    return {"body": body, "cta": cta, "send_as": send_as, "suppression_key": supp, "rationale": why}
