"""End-to-end self-test: python test_bot.py  (starts the server itself on a free port)."""
import glob, json, os, re, subprocess, sys, time, urllib.request, urllib.error

ROOT = os.path.dirname(os.path.abspath(__file__))
import socket
_s = socket.socket(); _s.bind(("127.0.0.1", 0)); PORT = str(_s.getsockname()[1]); _s.close()
BASE = "http://127.0.0.1:" + PORT
FAILS = []


def call(method, path, body=None):
    req = urllib.request.Request(BASE + path, method=method, data=json.dumps(body).encode() if body is not None else None,
                                 headers={"Content-Type": "application/json"})
    try:
        r = urllib.request.urlopen(req, timeout=30)
        return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read())


def check(cond, msg):
    if not cond:
        FAILS.append(msg)
        print("FAIL:", msg)


def load(pat):
    return [json.load(open(f, encoding="utf-8")) for f in sorted(glob.glob(os.path.join(ROOT, "expanded", pat)))]


def main():
    p = subprocess.Popen([sys.executable, "server.py"], cwd=ROOT, env={**os.environ, "PORT": PORT})
    try:
        for _ in range(50):
            try:
                call("GET", "/v1/healthz"); break
            except Exception:
                time.sleep(0.2)
        cats, ms, cs, ts = load("categories/*.json"), load("merchants/*.json"), load("customers/*.json"), load("triggers/*.json")
        for c in cats: check(call("POST", "/v1/context", {"scope": "category", "context_id": c["slug"], "version": 1, "payload": c, "delivered_at": "x"})[0] == 200, "cat push")
        for m in ms: call("POST", "/v1/context", {"scope": "merchant", "context_id": m["merchant_id"], "version": 1, "payload": m, "delivered_at": "x"})
        for c in cs: call("POST", "/v1/context", {"scope": "customer", "context_id": c["customer_id"], "version": 1, "payload": c, "delivered_at": "x"})
        s, h = call("GET", "/v1/healthz")
        check(h["contexts_loaded"] == {"category": 5, "merchant": 50, "customer": 200, "trigger": 0}, "healthz counts {}".format(h))
        check(call("POST", "/v1/context", {"scope": "merchant", "context_id": ms[0]["merchant_id"], "version": 1, "payload": ms[0], "delivered_at": "x"})[0] == 200, "equal version must be a 200 no-op")
        m_old = json.loads(json.dumps(ms[0])); 
        check(call("POST", "/v1/context", {"scope": "merchant", "context_id": ms[0]["merchant_id"], "version": 0, "payload": m_old, "delivered_at": "x"})[0] == 409, "older version must 409")
        check(call("POST", "/v1/context", {"scope": "bogus", "context_id": "a", "version": 1, "payload": {}})[0] == 400, "bad scope must 400")
        m2 = json.loads(json.dumps(ms[0])); m2["performance"]["views"] = 9999
        check(call("POST", "/v1/context", {"scope": "merchant", "context_id": ms[0]["merchant_id"], "version": 2, "payload": m2, "delivered_at": "x"})[0] == 200, "version bump")
        for t in ts: call("POST", "/v1/context", {"scope": "trigger", "context_id": t["id"], "version": 1, "payload": t, "delivered_at": "x"})

        allacts, tick_n = [], 0
        ids = [t["id"] for t in ts]
        for i in range(0, len(ids), 10):
            t0 = time.time()
            s, r = call("POST", "/v1/tick", {"now": "2026-04-26T10:30:00Z", "available_triggers": ids[i:i + 10]})
            check(s == 200 and time.time() - t0 < 5, "tick ok/fast")
            allacts += r["actions"]; tick_n += 1
        print("ticks:", tick_n, "actions:", len(allacts))
        req = {"conversation_id", "merchant_id", "customer_id", "send_as", "trigger_id", "template_name", "template_params", "body", "cta", "suppression_key", "rationale"}
        bodies, convs = set(), set()
        cat_by = {c["slug"]: c for c in cats}; m_by = {m["merchant_id"]: m for m in ms}
        for a in allacts:
            check(req <= set(a), "missing keys " + str(req - set(a)))
            check(a["body"].strip() != "", "empty body")
            check(not re.search(r"https?://|www\.", a["body"]), "URL in body")
            check(a["conversation_id"] not in convs, "dup conv id"); convs.add(a["conversation_id"])
            check(a["body"] not in bodies, "dup body {}".format(a["body"][:50])); bodies.add(a["body"])
            check(a["send_as"] in ("vera", "merchant_on_behalf"), "send_as")
            tab = cat_by[m_by[a["merchant_id"]]["category_slug"]]["voice"].get("vocab_taboo", [])
            for w in tab:
                w = re.sub(r"\(.*?\)", "", w).strip().lower()
                check(not w or w not in a["body"].lower(), "taboo '{}' in {}".format(w, a["conversation_id"]))
        mer_ticks = [a for a in allacts if a["send_as"] == "vera"]
        check(len(mer_ticks) > 10, "expected many merchant sends")
        # re-tick same triggers: dedup => no repeats
        s, r = call("POST", "/v1/tick", {"now": "x", "available_triggers": ids})
        check(all(a["body"] not in bodies for a in r["actions"]), "re-tick repeated a body")

        # expiry honoured on the simulated clock: IPL trigger expires 2026-04-26T23:59, so at 2026-05-20 it must not fire
        call("POST", "/v1/teardown", {})
        for c in cats: call("POST", "/v1/context", {"scope": "category", "context_id": c["slug"], "version": 1, "payload": c})
        for m in ms: call("POST", "/v1/context", {"scope": "merchant", "context_id": m["merchant_id"], "version": 1, "payload": m})
        for t in ts: call("POST", "/v1/context", {"scope": "trigger", "context_id": t["id"], "version": 1, "payload": t})
        s_, r_ = call("POST", "/v1/tick", {"now": "2026-05-20T10:00:00Z", "available_triggers": ["trg_010_ipl_match_delhi", "trg_018_supply_atorvastatin_recall"]})
        got = [a["trigger_id"] for a in r_["actions"]]
        check("trg_010_ipl_match_delhi" not in got and "trg_018_supply_atorvastatin_recall" in got, "expiry on simulated clock {}".format(got))
        # wall-clock far past every expiry => expiry ignored (bot must not go silent)
        call("POST", "/v1/teardown", {})
        for c in cats: call("POST", "/v1/context", {"scope": "category", "context_id": c["slug"], "version": 1, "payload": c})
        for m in ms: call("POST", "/v1/context", {"scope": "merchant", "context_id": m["merchant_id"], "version": 1, "payload": m})
        for t in ts: call("POST", "/v1/context", {"scope": "trigger", "context_id": t["id"], "version": 1, "payload": t})
        s_, r_ = call("POST", "/v1/tick", {"now": "2030-01-01T00:00:00Z", "available_triggers": ["trg_010_ipl_match_delhi"]})
        check(len(r_["actions"]) == 1, "wall-clock epoch mismatch must not silence the bot")
        # ----- replay scenarios (fresh merchant ids => independent state)
        mid = ms[5]["merchant_id"]
        auto = "Thank you for contacting us! Our team will respond shortly."
        acts = [call("POST", "/v1/reply", {"conversation_id": "conv_auto", "merchant_id": mid, "from_role": "merchant", "message": auto, "turn_number": n})[1]["action"] for n in (2, 3, 4)]
        check(acts == ["send", "wait", "end"], "auto-reply ladder {}".format(acts))
        mid2 = ms[6]["merchant_id"]
        r = call("POST", "/v1/reply", {"conversation_id": "conv_intent", "merchant_id": mid2, "from_role": "merchant", "message": "Ok lets do it. Whats next?", "turn_number": 3})[1]
        b = r.get("body", "").lower()
        check(r["action"] == "send" and any(w in b for w in ["done", "sending", "draft", "here", "confirm", "next"]) and not any(w in b for w in ["would you", "do you", "can you tell", "what if", "how about"]), "intent -> action {}".format(r))
        r = call("POST", "/v1/reply", {"conversation_id": "conv_host", "merchant_id": ms[7]["merchant_id"], "from_role": "merchant", "message": "Stop messaging me. This is useless spam.", "turn_number": 2})[1]
        check(r["action"] == "end", "hostile opt-out ends")
        cv = "conv_h2"; mm = ms[8]["merchant_id"]
        r1 = call("POST", "/v1/reply", {"conversation_id": cv, "merchant_id": mm, "from_role": "merchant", "message": "Why are you bothering me. This is useless.", "turn_number": 2})[1]
        r2 = call("POST", "/v1/reply", {"conversation_id": cv, "merchant_id": mm, "from_role": "merchant", "message": "can you also help me file my GST?", "turn_number": 3})[1]
        check(r1["action"] == "send" and r2["action"] == "send" and "outside" in r2["body"], "abuse then off-topic {} / {}".format(r1, r2))
        r = call("POST", "/v1/reply", {"conversation_id": "conv_nn", "merchant_id": ms[9]["merchant_id"], "from_role": "merchant", "message": "busy now, call me later", "turn_number": 2})[1]
        check(r["action"] == "wait", "not-now waits")
        s, r = call("POST", "/v1/reply", {"conversation_id": "x"})
        check(s == 400, "malformed reply 400")
        s, _ = call("POST", "/v1/tick", {"available_triggers": ["nope"]}); check(s == 200, "unknown trigger ok")
    finally:
        p.terminate()
    print("\nRESULT:", "ALL PASS" if not FAILS else "{} FAILURES".format(len(FAILS)))
    sys.exit(1 if FAILS else 0)


if __name__ == "__main__":
    main()
