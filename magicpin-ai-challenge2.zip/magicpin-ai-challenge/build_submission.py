"""Regenerate submission.jsonl from the canonical 30 test pairs (expanded/test_pairs.json)."""
import glob, json, os, sys
from bot import compose

ROOT = os.path.dirname(os.path.abspath(__file__))
EXP = os.path.join(ROOT, "expanded")


def load(pattern, key):
    out = {}
    for f in glob.glob(os.path.join(EXP, pattern)):
        d = json.load(open(f, encoding="utf-8"))
        out[d[key]] = d
    return out


def main(write=True):
    cats = {}
    for f in glob.glob(os.path.join(EXP, "categories", "*.json")):
        d = json.load(open(f, encoding="utf-8")); cats[d["slug"]] = d
    M, C, T = load("merchants/*.json", "merchant_id"), load("customers/*.json", "customer_id"), load("triggers/*.json", "id")
    rows = []
    for p in json.load(open(os.path.join(EXP, "test_pairs.json")))["pairs"]:
        m, t = M[p["merchant_id"]], T[p["trigger_id"]]
        c = C.get(p["customer_id"]) if p.get("customer_id") else None
        r = compose(cats[m["category_slug"]], m, t, c)
        rows.append({"test_id": p["test_id"], **r})
    if write:
        with open(os.path.join(ROOT, "submission.jsonl"), "w", encoding="utf-8") as f:
            for r in rows:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
    return rows


if __name__ == "__main__":
    for r in main(write="--dry" not in sys.argv):
        print("\n[{}] {} | {} | {}\n{}\n  -> {}".format(r["test_id"], r["send_as"], r["cta"], r["suppression_key"], r["body"], r["rationale"]))
